from flask import Blueprint, jsonify, render_template, request
from app.models.transport_graph import TransportGraph
from app.algorithms.dijkstra_with_transfers import find_shortest_path
import os

bp = Blueprint('routes', __name__)
graph = TransportGraph()

@bp.route('/')
def home():
    return render_template('index.html')

@bp.route('/api/stations')
def get_stations():
    try:
        graph.load_from_json(os.path.join('data', 'station_network.json'))
        return jsonify(list(graph.graph.keys()))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@bp.route('/api/route')
def get_route():
    try:
        start = request.args.get('start')
        end = request.args.get('end')
        
        if not start or not end:
            return jsonify({"error": "Missing stations"}), 400
        
        if not graph.graph:
            graph.load_from_json(os.path.join('data', 'station_network.json'))
        
        time, path = find_shortest_path(graph, start, end)
        
        if not path:
            return jsonify({"error": "No route found"}), 404
        
        return jsonify({"path": path, "time": time})
    except Exception as e:
        return jsonify({"error": str(e)}), 500